# MediaVision HarmonyOS 0.4.5

最低 HarmonyOS 6.0.0 / API20。SDK可免费商用。

- SDK：sdk/harmonyos（ARM64/x86_64，共享库、静态核心及ArkTS HAR）。
- 公共接口：include/mvs/harmonyos.h；C/C++示例：demos/harmonyos-native。
- 相机实时Demo：demos/harmonyos；模型：models/harmonyos/mediavision.mvsmodels。
- HAP：installers/harmonyos/MediaVisionDemo-api20-unsigned.hap，安装前必须配置自己的签名。
- 接入与构建、模型和padding接口：docs/HARMONYOS.md。

使用最新官方DevEco Studio与配套SDK/Hvigor/Node，运行tools/build_harmonyos_demo.py准备完整Demo构建目录；该工具使用发布二进制。再在DevEco Studio打开生成的目录、配置自己的设备签名并运行。

模型采用系统MindSpore Lite/NNRT加速器，效果采用Vulkan。已在ADA-AL00 / HarmonyOS6.1.0.135 / API24验证；x86_64和最低API20为编译支持范围。

Minimum HarmonyOS 6.0.0 / API20. The SDK is free for commercial integration. Native ARM64/x86_64 libraries, HAR, public C/C++ APIs, live-camera demo, encrypted models and an unsigned HAP are included. Build the demo with official DevEco Studio tools and configure your own signing credentials. Models use strict NNRT/NPU and effects use Vulkan. Device testing covers ARM64/API24.

File checksums are listed in PACKAGE-MANIFEST.json. Verify extracted contents:

```bash
python3 -c 'import json,hashlib,pathlib; m=json.load(open("PACKAGE-MANIFEST.json")); assert all(hashlib.sha256(pathlib.Path(f["path"]).read_bytes()).hexdigest()==f["sha256"] for f in m["files"]); print("PASS")'
```

Repository: https://github.com/qmy1990/MediaVision
